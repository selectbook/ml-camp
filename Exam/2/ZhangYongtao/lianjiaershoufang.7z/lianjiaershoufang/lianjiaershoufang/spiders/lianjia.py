# -*- coding: utf-8 -*-
import scrapy
from lianjiaershoufang.extras import utils
import requests
from bs4 import BeautifulSoup
import time
import os

class LianjiaSpider(scrapy.Spider):
    name = 'lianjia'
    allowed_domains = ['https://sh.lianjia.com/ershoufang/changning/']
    start_urls = ['https://sh.lianjia.com/ershoufang/changning//']

    def filter(self,area,totalPrice):
        filter_flag = True if (int(totalPrice/area)>9) and (area <50) else False    #去除面积50平方以下和单价9万以上
        return filter_flag
    
    def parse(self, response):
        #driver = response.driver
        #house_infos = utils.find_elements_by_css_selector(driver, 'body > div.content > div.leftContent > ul')
        text = response.text
        bs = BeautifulSoup(text, 'html5lib') 
        for info in bs.select('body > div.content > div.leftContent > ul'):
            title = info.select('> div.info.clear > div.title > a').text                 #获取标题
            href = info.select('> div.info.clear > div.title > a').get('href')         #获取链接
            total_price = title.split('')[2]                                                                     #获取总价
            total_price = os.path.splitext(total_price)[0]
            area = info.select('> div.info.clear > div.address > div.houseinfo > (text)').split('|')[3]   #获取面积
            area = os.path.splitext(area)[0]         #将数字和汉字分开获得面积
            unit_price = int(totalPrice/area)                                                                           #获取单价
            if not self.filter(area,totalPrice):                            #调用函数过滤不满足条件的信息
                yield {'title':title, 'url':href, 'unit_price':uint_price, 'area':area, 'total_price':total_price}   
        #driver.quit()
