# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html


class DoubanloginPipeline(object):
    def __init__(self):
        self.filename = 'hot_topic.csv'
        self.f = None

    def open_spider(self, spider):
        if spider.name == 'douban': # 确认数据来自你要处理的spider
            self.f = open(self.filename, 'w+', encoding='utf-8')

    def close_spider(self, spider):
        if self.f:
            self.f.close()

    def process_item(self, item, spider):
        if spider.name == 'douban':
            topic = item['topic']
            browser_nimber = item['number']
            self.f.write('%s, %s\n' % (topic, browser_number))
        else:
            return item
