# -*- coding: utf-8 -*-
import scrapy
from selenium import webdriver
from doubanlogin.extras import utils
import requests
from bs4 import BeautifulSoup
import time
import os

class DoubanSpider(scrapy.Spider):
    name = 'douban'
    allowed_domains = ['www.douban.com']
    start_urls = ['http://www.douban.com/']


    def parse(self, response):
        driver = response.driver
        login_user_name = utils.find_element_by_css_selector(driver,'input#form_email.inp')     #定位用户名
        login_password = utils.find_element_by_css_selector(driver,'input#form_password.inp')   #定位密码
        captcha_fileld = utils.find_element_by_css_selector(driver,'input#captcha_field.inp')                        #定位验证码
        login_button = utils.find_element_by_css_selector(driver,'input.bn-submit')        #定位提交按钮
        if captcha_fileld:            #找到验证码输入框，输入验证码
            user_name = input('请输入用户名:')
            login_user_name.send_keys(user_name)
            password = input('请输入密码:')
            login_password.send_keys(password)
            captcha = input('请输入验证码：')
            captcha_fileld.send_keys(captcha)
            login_button.click()
        else:                        #未找到验证码输入框，直接输入用户名和密码
            user_name = input('请输入用户名:')
            login_user_name.send_keys(user_name)
            password = input('请输入密码:')
            login_password.send_keys(password)
            login_button.click()
        text = response.text
        bs = BeautifulSoup(text, 'html5lib')
        for item in bs.select('#content > div > div.aside > div:nth-child(4) > ul'):
            topic = item.select('a').text
            browser_number = item.select('span').text
            number = os.path.splitext(browser_number)[0]
            yield {'topic':topic, 'number':number}   
